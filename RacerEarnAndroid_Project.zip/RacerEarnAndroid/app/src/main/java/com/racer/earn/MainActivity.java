package com.racer.earn;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int purple = Color.rgb(145, 45, 255);
    int bg = Color.rgb(15, 10, 24);
    TextView balance;
    double earnings = 0.00;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 34, 24, 24);
        page.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("⚡ RACER EARN");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView tagline = new TextView(this);
        tagline.setText("WATCH ADS  •  EARN REWARDS");
        tagline.setTextColor(0xFFCEAEFF);
        tagline.setTextSize(13);
        tagline.setGravity(Gravity.CENTER);
        page.addView(tagline);

        TextView card = new TextView(this);
        card.setText("YOUR REWARD BALANCE");
        card.setTextColor(0xFFD9C6FF);
        card.setTextSize(14);
        card.setGravity(Gravity.CENTER);
        card.setPadding(10, 28, 10, 6);
        page.addView(card);

        balance = new TextView(this);
        balance.setText("$0.00");
        balance.setTextColor(Color.WHITE);
        balance.setTextSize(38);
        balance.setTypeface(null, Typeface.BOLD);
        balance.setGravity(Gravity.CENTER);
        page.addView(balance, new LinearLayout.LayoutParams(-1, 65));

        TextView target = new TextView(this);
        target.setText("Daily target: $5.00  |  Minimum withdrawal: $5.00");
        target.setTextColor(0xFFB9A8CC);
        target.setTextSize(12);
        target.setGravity(Gravity.CENTER);
        target.setPadding(0, 8, 0, 24);
        page.addView(target);

        Button watch = new Button(this);
        watch.setText("WATCH AD (DEMO)");
        watch.setTextColor(Color.WHITE);
        watch.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        page.addView(watch, new LinearLayout.LayoutParams(-1, 58));
        watch.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Ad demo")
            .setMessage("No real advertisement is connected yet. Rewards are not credited in this demo.")
            .setPositiveButton("OK", null).show());

        Button withdraw = new Button(this);
        withdraw.setText("WITHDRAW");
        withdraw.setTextColor(Color.WHITE);
        withdraw.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF342342));
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 58);
        wp.topMargin = 14;
        page.addView(withdraw, wp);
        withdraw.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Withdrawals not active")
            .setMessage("Mobile Money payouts need a verified payment provider and funded wallet. This prototype does not send money.")
            .setPositiveButton("OK", null).show());

        TextView methods = new TextView(this);
        methods.setText("PAYMENT METHODS\nMTN MoMo  •  Telecel Cash  •  AT Money");
        methods.setTextColor(0xFFD9C6FF);
        methods.setTextSize(14);
        methods.setGravity(Gravity.CENTER);
        methods.setPadding(0, 34, 0, 0);
        page.addView(methods);

        TextView note = new TextView(this);
        note.setText("Prototype only — no real ads, earnings, accounts or payments are connected.");
        note.setTextColor(0xFF9E91AA);
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 28, 0, 0);
        page.addView(note);

        setContentView(page);
    }
}
